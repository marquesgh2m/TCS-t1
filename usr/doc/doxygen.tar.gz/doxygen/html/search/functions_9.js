var searchData=
[
  ['sched_5flottery',['sched_lottery',['../scheduler_8h.html#aa067fda22888ad77001f5d6162933449',1,'sched_lottery(void):&#160;scheduler.c'],['../scheduler_8c.html#aa067fda22888ad77001f5d6162933449',1,'sched_lottery(void):&#160;scheduler.c']]],
  ['sched_5fpriorityrr',['sched_priorityrr',['../scheduler_8h.html#a7a2dc50bb1ab2a6ded651fbabfdf70e2',1,'sched_priorityrr(void):&#160;scheduler.c'],['../scheduler_8c.html#a7a2dc50bb1ab2a6ded651fbabfdf70e2',1,'sched_priorityrr(void):&#160;scheduler.c']]],
  ['sched_5frma',['sched_rma',['../scheduler_8h.html#a40c41b93afbdf4fd8564dbea90f163e5',1,'sched_rma(void):&#160;scheduler.c'],['../scheduler_8c.html#a40c41b93afbdf4fd8564dbea90f163e5',1,'sched_rma(void):&#160;scheduler.c']]],
  ['sched_5frr',['sched_rr',['../scheduler_8c.html#a2feb8dfa22662ba4fc6a41e74f8837db',1,'scheduler.c']]]
];
