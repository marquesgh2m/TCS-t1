var searchData=
[
  ['name',['name',['../structtcb__entry.html#ad7bfcb0f4b58b797af44f3a078abebff',1,'tcb_entry']]],
  ['netif_5frecv',['netif_recv',['../ustack_8h.html#a90bcd2a3d71369a59b70de161ecf5921',1,'ustack.h']]],
  ['netif_5fsend',['netif_send',['../ustack_8h.html#afdf732d4a84f42f4a152bb79e35a4076',1,'ustack.h']]],
  ['next',['next',['../structlist.html#a1900fe79e875e2838625b2eb60837f8f',1,'list::next()'],['../unionmem__header__union.html#a22eb41be35488312c1e42462d5679d64',1,'mem_header_union::next()'],['../structmem__block.html#ac3317f1b6603856e265b1ba15c4a99b8',1,'mem_block::next()']]],
  ['ni_5finit',['ni_init',['../noc_8c.html#acb44cf0de3a986b823c53d881bff9568',1,'ni_init(void):&#160;noc.c'],['../noc_8h.html#acb44cf0de3a986b823c53d881bff9568',1,'ni_init(void):&#160;noc.c']]],
  ['ni_5fisr',['ni_isr',['../noc_8c.html#a7ca8f6357767be7d8d8f31a1f68902a1',1,'ni_isr(void *arg):&#160;noc.c'],['../noc_8h.html#a7ca8f6357767be7d8d8f31a1f68902a1',1,'ni_isr(void *arg):&#160;noc.c']]],
  ['noc_2ec',['noc.c',['../noc_8c.html',1,'']]],
  ['noc_2eh',['noc.h',['../noc_8h.html',1,'']]]
];
