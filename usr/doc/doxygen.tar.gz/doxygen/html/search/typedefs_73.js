var searchData=
[
  ['sem_5ft',['sem_t',['../semaphore_8h.html#ad7630848c81d49708045a351922eb6b5',1,'semaphore.h']]]
];
