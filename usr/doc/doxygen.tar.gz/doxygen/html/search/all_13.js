var searchData=
[
  ['waiting',['waiting',['../structmtx.html#a14e1d218cc3d0cd3e74ae6de1eb69212',1,'mtx']]]
];
