var searchData=
[
  ['kernel_2eh',['kernel.h',['../kernel_8h.html',1,'']]],
  ['kprintf',['kprintf',['../kprintf_8h.html#a80682af286bf85737036e5c569ab942a',1,'kprintf(const int8_t *fmt,...):&#160;kprintf.c'],['../kprintf_8c.html#a80682af286bf85737036e5c569ab942a',1,'kprintf(const int8_t *fmt,...):&#160;kprintf.c']]],
  ['kprintf_2ec',['kprintf.c',['../kprintf_8c.html',1,'']]],
  ['kprintf_2eh',['kprintf.h',['../kprintf_8h.html',1,'']]],
  ['krnl_5fcurrent_5ftask',['krnl_current_task',['../kernel_8h.html#a784d1710b495108c11d5d11c8fb43516',1,'kernel.h']]],
  ['krnl_5fdelay_5fqueue',['krnl_delay_queue',['../kernel_8h.html#ae4bf97399eec663eacfa816d0b81082e',1,'kernel.h']]],
  ['krnl_5fevent_5fqueue',['krnl_event_queue',['../kernel_8h.html#a5903b31cf96f8d2697316b67a0b1f10b',1,'kernel.h']]],
  ['krnl_5ffree',['krnl_free',['../kernel_8h.html#a6bada0206d47773f897a3c58528c794a',1,'kernel.h']]],
  ['krnl_5fheap',['krnl_heap',['../kernel_8h.html#a2db720ce5f1ce81dba0cf5c773b2610a',1,'kernel.h']]],
  ['krnl_5fheap_5fptr',['krnl_heap_ptr',['../malloc_8h.html#a3aa03a56699687f10ab0616b944da63c',1,'malloc.h']]],
  ['krnl_5fpcb',['krnl_pcb',['../kernel_8h.html#af3055369b0f2af2ae86e2d95ec1b87b7',1,'kernel.h']]],
  ['krnl_5frt_5fqueue',['krnl_rt_queue',['../kernel_8h.html#ada5d16f9dd5684be324c7cf3a06d05bf',1,'kernel.h']]],
  ['krnl_5frun_5fqueue',['krnl_run_queue',['../kernel_8h.html#a5141ea9b1498a972a227094289188047',1,'kernel.h']]],
  ['krnl_5fschedule',['krnl_schedule',['../kernel_8h.html#aa32f6edbc8444a2acb45729b024d13d5',1,'kernel.h']]],
  ['krnl_5ftask',['krnl_task',['../kernel_8h.html#a0b347b2a9f226d4bc709a296b5cbc189',1,'kernel.h']]],
  ['krnl_5ftasks',['krnl_tasks',['../kernel_8h.html#a3289a2f20f14e35ff9e127fa281318b6',1,'kernel.h']]],
  ['krnl_5ftcb',['krnl_tcb',['../kernel_8h.html#a3fc9c4d501dff3892623466e7d1c479d',1,'kernel.h']]]
];
