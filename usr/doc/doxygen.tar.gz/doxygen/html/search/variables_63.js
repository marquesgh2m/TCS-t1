var searchData=
[
  ['capacity',['capacity',['../structtcb__entry.html#a2a3c8e5e81c910ccd845a8d1f58d550a',1,'tcb_entry']]],
  ['capacity_5frem',['capacity_rem',['../structtcb__entry.html#a559dce8ac2982d3c8f46808ddc52bbb9',1,'tcb_entry']]],
  ['cond_5fqueue',['cond_queue',['../structcondvar.html#abf91dd97763d95af19ee92a17f55afb8',1,'condvar']]],
  ['coop_5fcswitch',['coop_cswitch',['../structpcb__entry.html#ac5899befd89fa0e8b2aeceed85e01415',1,'pcb_entry']]],
  ['count',['count',['../structsem.html#a798dc7e825b1e632b2db49b473b17636',1,'sem']]],
  ['critical',['critical',['../structtcb__entry.html#ab76fc52c033f2b9cd0adc9474fcde5ef',1,'tcb_entry']]]
];
