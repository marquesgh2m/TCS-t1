var searchData=
[
  ['calloc',['calloc',['../malloc_8h.html#a5cd906b2cf10b5e5e898c7cc0a705860',1,'calloc(uint32_t qty, uint32_t type_size):&#160;malloc.c'],['../malloc_8c.html#a5cd906b2cf10b5e5e898c7cc0a705860',1,'calloc(uint32_t qty, uint32_t type_size):&#160;malloc.c']]]
];
