var searchData=
[
  ['data',['data',['../structqueue.html#a794929032d575599c02f795cea4b3118',1,'queue']]],
  ['deadline',['deadline',['../structtcb__entry.html#a14ef4f38d7589e42ac7847b2bcc3443f',1,'tcb_entry']]],
  ['deadline_5fmisses',['deadline_misses',['../structtcb__entry.html#a4594d17577feba0bd0825c8ef5e693db',1,'tcb_entry']]],
  ['deadline_5frem',['deadline_rem',['../structtcb__entry.html#af2ba0dde6c7ae71b6341714bf096cc80',1,'tcb_entry']]],
  ['delay',['delay',['../structtcb__entry.html#ab29fad6168f140493ddc8f860fadc3bc',1,'tcb_entry']]]
];
