var searchData=
[
  ['free',['free',['../malloc_8h.html#afbedc913aa4651b3c3b4b3aecd9b4711',1,'free(void *ptr):&#160;malloc.c'],['../malloc_8c.html#afbedc913aa4651b3c3b4b3aecd9b4711',1,'free(void *ptr):&#160;malloc.c']]]
];
