var searchData=
[
  ['panic',['panic',['../panic_8h.html#afaa3b7dc21eaab894153ef5cf7bf9a0f',1,'panic(int32_t cause):&#160;panic.c'],['../panic_8c.html#afaa3b7dc21eaab894153ef5cf7bf9a0f',1,'panic(int32_t cause):&#160;panic.c']]],
  ['panic_2ec',['panic.c',['../panic_8c.html',1,'']]],
  ['panic_2eh',['panic.h',['../panic_8h.html',1,'']]],
  ['pcb_5fentry',['pcb_entry',['../structpcb__entry.html',1,'']]],
  ['period',['period',['../structtcb__entry.html#a85e14b4c040e0535b45b52a7ee7c9a94',1,'tcb_entry']]],
  ['pkt_5fqueue',['pkt_queue',['../structuudp.html#a173d6e92d93ed6c5a8e6bae66a66c132',1,'uudp']]],
  ['pktdrv_5fports',['pktdrv_ports',['../noc_8h.html#a28c51954b0e202d17770b6f597d58e35',1,'noc.h']]],
  ['pktdrv_5fqueue',['pktdrv_queue',['../noc_8h.html#ac96abbb61b929a8293778fe63006aca4',1,'noc.h']]],
  ['pktdrv_5ftqueue',['pktdrv_tqueue',['../noc_8h.html#a6e2b90dbd05cdac119b8d3296579de0a',1,'noc.h']]],
  ['preempt_5fcswitch',['preempt_cswitch',['../structpcb__entry.html#af49c7195c79f5de2d70825e2252c8d77',1,'pcb_entry']]],
  ['priority',['priority',['../structtcb__entry.html#a5a925d67b6f5391815abcbd2c251c77d',1,'tcb_entry']]],
  ['priority_5frem',['priority_rem',['../structtcb__entry.html#a63888ca7a7a923f912bf3a404d1261ca',1,'tcb_entry']]],
  ['processor_2ec',['processor.c',['../processor_8c.html',1,'']]],
  ['processor_2eh',['processor.h',['../processor_8h.html',1,'']]],
  ['pstack',['pstack',['../structtcb__entry.html#a48bcced7fc892ae8db7138786e38a898',1,'tcb_entry']]],
  ['ptask',['ptask',['../structtcb__entry.html#a7ed7f2d228da0039f065f0c8a756b46d',1,'tcb_entry']]]
];
