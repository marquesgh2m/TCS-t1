var searchData=
[
  ['tail',['tail',['../structqueue.html#ada0fe9a078df1d07623c761f2e8376ad',1,'queue']]],
  ['task_2ec',['task.c',['../task_8c.html',1,'']]],
  ['task_2eh',['task.h',['../task_8h.html',1,'']]],
  ['task_5fcontext',['task_context',['../structtcb__entry.html#a589e6c94b17a97df5d22edf504acfd42',1,'tcb_entry']]],
  ['tcb_5fentry',['tcb_entry',['../structtcb__entry.html',1,'']]],
  ['tick_5ftime',['tick_time',['../structpcb__entry.html#a998d1bf7b5ac3d6b0b9c4c6c7a0ebec6',1,'pcb_entry']]]
];
