var searchData=
[
  ['tail',['tail',['../structqueue.html#ada0fe9a078df1d07623c761f2e8376ad',1,'queue']]],
  ['task_5fcontext',['task_context',['../structtcb__entry.html#a589e6c94b17a97df5d22edf504acfd42',1,'tcb_entry']]],
  ['tick_5ftime',['tick_time',['../structpcb__entry.html#a998d1bf7b5ac3d6b0b9c4c6c7a0ebec6',1,'pcb_entry']]]
];
