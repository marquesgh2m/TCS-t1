var searchData=
[
  ['s',['s',['../unionmem__header__union.html#a8e9bc77f2cf7596a7503f50ef29019f9',1,'mem_header_union']]],
  ['sched_5fbe',['sched_be',['../structpcb__entry.html#aaf3abd937873f1cfa6cea1f4921d5f7a',1,'pcb_entry']]],
  ['sched_5frt',['sched_rt',['../structpcb__entry.html#ad3c7b06bf949312a542d036f92d2619a',1,'pcb_entry']]],
  ['sem_5fqueue',['sem_queue',['../structsem.html#a723ac960b2566b855b905fa4aa324f9b',1,'sem']]],
  ['size',['size',['../structmem__chunk.html#a6c249814794488c18a42bcf180e3c024',1,'mem_chunk::size()'],['../unionmem__header__union.html#ab0a6578a8d52fd76a933d21273e73e08',1,'mem_header_union::size()'],['../structmem__block.html#a5ff4ee5dcd970bbc4951eb108c5eec4b',1,'mem_block::size()'],['../structqueue.html#af80cfabc36286195365b6d666d518504',1,'queue::size()']]],
  ['stack_5fsize',['stack_size',['../structtcb__entry.html#a2174ff4c5cf178e9dc3d652c472b23dd',1,'tcb_entry']]],
  ['state',['state',['../structtcb__entry.html#a67f430ab50cb8ff9133e133fc240f3d7',1,'tcb_entry']]]
];
