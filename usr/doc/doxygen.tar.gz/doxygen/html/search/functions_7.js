var searchData=
[
  ['netif_5frecv',['netif_recv',['../ustack_8h.html#a90bcd2a3d71369a59b70de161ecf5921',1,'ustack.h']]],
  ['netif_5fsend',['netif_send',['../ustack_8h.html#afdf732d4a84f42f4a152bb79e35a4076',1,'ustack.h']]],
  ['ni_5fflush',['ni_flush',['../ni__hermes_8c.html#a440c71c3a4d4c4f5704de080f85f1428',1,'ni_flush(uint16_t pkt_size):&#160;ni_hermes.c'],['../ni__generic_8h.html#a440c71c3a4d4c4f5704de080f85f1428',1,'ni_flush(uint16_t pkt_size):&#160;ni_hermes.c']]],
  ['ni_5finit',['ni_init',['../noc_8c.html#acb44cf0de3a986b823c53d881bff9568',1,'ni_init(void):&#160;noc.c'],['../noc_8h.html#acb44cf0de3a986b823c53d881bff9568',1,'ni_init(void):&#160;noc.c']]],
  ['ni_5fisr',['ni_isr',['../noc_8c.html#a7ca8f6357767be7d8d8f31a1f68902a1',1,'ni_isr(void *arg):&#160;noc.c'],['../noc_8h.html#a7ca8f6357767be7d8d8f31a1f68902a1',1,'ni_isr(void *arg):&#160;noc.c']]],
  ['ni_5fread_5fpacket',['ni_read_packet',['../ni__hermes_8c.html#a7185a5c02c3e5dd69df562a2cc3033b1',1,'ni_read_packet(uint16_t *buf, uint16_t pkt_size):&#160;ni_hermes.c'],['../ni__generic_8h.html#a7185a5c02c3e5dd69df562a2cc3033b1',1,'ni_read_packet(uint16_t *buf, uint16_t pkt_size):&#160;ni_hermes.c']]],
  ['ni_5fready',['ni_ready',['../ni__hermes_8c.html#ac935a14a6eed5d7cacb21ecc72ec2fa5',1,'ni_ready(void):&#160;ni_hermes.c'],['../ni__generic_8h.html#ac935a14a6eed5d7cacb21ecc72ec2fa5',1,'ni_ready(void):&#160;ni_hermes.c']]],
  ['ni_5fwrite_5fpacket',['ni_write_packet',['../ni__hermes_8c.html#a29d4f0701c32bc2cb4812bfde7e26f01',1,'ni_write_packet(uint16_t *buf, uint16_t pkt_size):&#160;ni_hermes.c'],['../ni__generic_8h.html#a29d4f0701c32bc2cb4812bfde7e26f01',1,'ni_write_packet(uint16_t *buf, uint16_t pkt_size):&#160;ni_hermes.c']]]
];
